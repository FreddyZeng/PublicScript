#define get_salutation hithere_LTX_get_salutation
#include "../../module.h"

const char * get_salutation(void)
{
    return "Hi there";
}
