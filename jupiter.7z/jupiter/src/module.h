#ifndef MODULE_H_INCLUDED
#define MODULE_H_INCLUDED

#define GET_SALUTATION_SYM "get_salutation"

typedef const char * get_salutation_t(void);
const char * get_salutation(void);

#endif /* MODULE_H_INCLUDED */
