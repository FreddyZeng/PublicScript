#include "config.h"

#include "libjupiter.h"
#include "jupcommon.h"

int jupiter_print(const char * salutation, const char * name)
{
    return print_routine(salutation, name);
}
