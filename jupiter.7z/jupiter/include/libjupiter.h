#ifndef LIBJUPITER_H_INCLUDED
#define LIBJUPITER_H_INCLUDED

int jupiter_print(const char * salutation, const char * name);

#endif /* LIBJUPITER_H_INCLUDED */
