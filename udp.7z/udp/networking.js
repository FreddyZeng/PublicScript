(function(root) {
  // Set-up the NameSpace
  root.chromeNetworking = new (function() {
    var NoAddressException = "No Address";
    var NotConnectedException = "Not Connected";

    var socket = chrome.sockets.udp;

    var baseClient = function() {
      var address, port;
      var socketInfo;
      var connected = false;
      var callbacks = [];
      var self = this;

      this.connect = function(inAddress, inPort, callback, responseHandler) {

        address = inAddress;
        port = inPort || this.defaultPort;

        console.log('creating socket', address, port);

        socket.create({}, function(_socketInfo) {
          socketInfo = _socketInfo;
          console.log(socketInfo)
          debugger;
          socket.bind(socketInfo.socketId, address, 0, function(connectResult) {
            connected = (connectResult == 0);
            console.log('connected'
            )
            console.log(connectResult == 0)
            debugger;
            socket.onReceive.addListener(function(result) {
              if (callbacks.length > 0) {
                callbacks.shift()(result);
              }
            });

            callback(connected);
          });
        });
      };

      this.send = function(data, callback) {
        callback = callback || function() {};

        if(connected == false) return;

        socket.send(socketInfo.socketId, data, address, port, function(sendResult) {
          callback(sendResult);
        });
      };

      this.receive = function(callback) {
        if(connected == false) return;
        callbacks.push(callback);
      };

      this.disconnect = function() {
        if(connected == false) return;

        socket.close(socketInfo.socketId, function() {
          connected = false;
        });
      };
    };

    let utf8Encode = new TextEncoder();
    
    function createDNSPacket(domain) {
      var domainUint8array = new TextEncoder("utf-8").encode(domain);
      var domainSize = domainUint8array.byteLength + 2;
      console.log(domainSize);
      
      const headerBuffer = new ArrayBuffer(12);
      const header = new DataView(headerBuffer);
      header.setUint16(0, 1)
      header.setUint16(2, 100)
      header.setUint16(4, 1)
      header.setUint16(6, 0)
      header.setUint16(8, 0)
      header.setUint16(10, 0)

      const questionBuffer = new ArrayBuffer(4);
      const question = new DataView(questionBuffer);
      question.setUint16(0, 1)
      question.setUint16(2, 1)

      var concateBuff = new Uint8Array(domainUint8array.byteLength + headerBuffer.byteLength + questionBuffer.byteLength + 2);
      concateBuff.set(new Uint8Array(headerBuffer), 0);
      concateBuff.set(new Uint16Array(1), headerBuffer.byteLength);
      concateBuff.set(domainUint8array, headerBuffer.byteLength + 1);
      concateBuff.set(new Uint16Array(1), headerBuffer.byteLength + 2);
      concateBuff.set(new Uint8Array(questionBuffer),  headerBuffer.byteLength + domainUint8array.byteLength + 2);

      return concateBuff;
    }


    var _EchoClient = function(defaultPort) {
      return function() {
        var client = new baseClient();
        this.defaultPort = defaultPort;

        this.connect = client.connect;
        this.disconnect = client.disconnect;

        this.callbacks = {};
        this.echo = function(data, callback) {
          if (!this.callbacks[data]) {
            this.callbacks[data] = [];
          }
          this.callbacks[data].push(callback);
          var self = this;
          
          var domain = 'baidu.com';


          var bff = createDNSPacket(domain);
          client.send(bff, function(sendResult) {
            console.log('send', sendResult);
            client.receive(function(receiveResult) {
              var u32 = new Uint32Array(receiveResult.data);
              var m = u32[0];
              console.log('m：', m);
              var cbs = self.callbacks[m];
              if (cbs) {
                cb = cbs.shift();
                if (cb) {
                  cb(receiveResult);
                }
              }
            });
          });
        };
      };
    };

    return {
      // Clients
      clients: {
        echoClient: _EchoClient(7)
      },
      // Exceptions
      exceptions: {
        NoAddressException: NoAddressException,
        NotConnectedException: NotConnectedException
      }
    };
  })();
})(this);
